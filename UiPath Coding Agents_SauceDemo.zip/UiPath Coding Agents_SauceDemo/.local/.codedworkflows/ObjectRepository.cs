using UiPath.CodedWorkflows.DescriptorIntegration;

namespace Saucedemo.ObjectRepository
{
    public static class Descriptors
    {
        public static class Edge__Swag_Labs_app
        {
            static string _reference = "d1mKlxCDdkScUHoAOnUyQA/Y1XhukCbnUSF9nePprH0Ug";
            public static _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Customer_Details Edge__Swag_Labs_Customer_Details { get; private set; } = new _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Customer_Details();
            public static _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Inventory Edge__Swag_Labs_Inventory { get; private set; } = new _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Inventory();
            public static _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Login Edge__Swag_Labs_Login { get; private set; } = new _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Login();
            public static _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Shopping_Cart Edge__Swag_Labs_Shopping_Cart { get; private set; } = new _Implementation._Edge__Swag_Labs_app.__Edge__Swag_Labs_Shopping_Cart();
            public static _Implementation._Edge__Swag_Labs_app.__Sause_Labs___Payment Sause_Labs___Payment { get; private set; } = new _Implementation._Edge__Swag_Labs_app.__Sause_Labs___Payment();
        }
    }
}

namespace Saucedemo._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }
        public string Reference { get; set; }
        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }
        public string Reference { get; set; }
        public string DisplayName { get; set; }
        public IElementDescriptor ParentElement { get; set; }
        public IElementDescriptor Element { get; set; }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details
    {
        public class __Continue : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Continue(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/SinaQcxNu0etHdKyWt4Phg",
                    DisplayName = "Continue",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details
    {
        public class __INPUT_first_name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __INPUT_first_name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/DlWwpDwdMUyBk7VK0ZTGHg",
                    DisplayName = "INPUT first-name",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details
    {
        public class __INPUT_last_name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __INPUT_last_name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/BDaX8RmSX0aHns31AOKJyA",
                    DisplayName = "INPUT last-name",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details
    {
        public class __INPUT_postal_code : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __INPUT_postal_code(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/o129JAyngEuBJgvPLhOFTw",
                    DisplayName = "INPUT postal-code",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app
    {
        public class __Edge__Swag_Labs_Customer_Details : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge__Swag_Labs_Customer_Details()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/4nk0SA78VkSvijgCAzCTuQ",
                    DisplayName = "Edge: Swag Labs Customer Details",
                    Screen = this
                };
                Continue = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__Continue(this, null);
                INPUT_first_name = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_first_name(this, null);
                INPUT_last_name = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_last_name(this, null);
                INPUT_postal_code = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_postal_code(this, null);
            }

            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__Continue Continue { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_first_name INPUT_first_name { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_last_name INPUT_last_name { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Customer_Details.__INPUT_postal_code INPUT_postal_code { get; private set; }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory
    {
        public class __A : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __A(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/YnNUa5KP9EKMjSymHlGG7Q",
                    DisplayName = "A",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory
    {
        public class __Add_to_cart : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_to_cart(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/2fI3-QIM4UKNAcq_QwaeNg",
                    DisplayName = "Add to cart",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory
    {
        public class __Add_to_cart__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_to_cart__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/49YnE-nimUS8DyR7LCZj_g",
                    DisplayName = "Add to cart (1)",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app
    {
        public class __Edge__Swag_Labs_Inventory : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge__Swag_Labs_Inventory()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/8yYz66AeNUKsH4g3xVR0ZA",
                    DisplayName = "Edge: Swag Labs Inventory",
                    Screen = this
                };
                A = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__A(this, null);
                Add_to_cart = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__Add_to_cart(this, null);
                Add_to_cart__1_ = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__Add_to_cart__1_(this, null);
            }

            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__A A { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__Add_to_cart Add_to_cart { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Inventory.__Add_to_cart__1_ Add_to_cart__1_ { get; private set; }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Login
    {
        public class __INPUT_password : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __INPUT_password(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/2lWJSYl7uU2mo_zoUln2fg",
                    DisplayName = "INPUT password",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Login
    {
        public class __INPUT_user_name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __INPUT_user_name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/CXp1Tqq7oE2TXSCzbr2lHw",
                    DisplayName = "INPUT user-name",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Login
    {
        public class __Login : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Login(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/LyYEYLtk_EeJEPuF601RjA",
                    DisplayName = "Login",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app
    {
        public class __Edge__Swag_Labs_Login : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge__Swag_Labs_Login()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/ngMm1c6NEEe8aiiCxJOTJg",
                    DisplayName = "Edge: Swag Labs Login",
                    Screen = this
                };
                INPUT_password = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__INPUT_password(this, null);
                INPUT_user_name = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__INPUT_user_name(this, null);
                Login = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__Login(this, null);
            }

            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__INPUT_password INPUT_password { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__INPUT_user_name INPUT_user_name { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Login.__Login Login { get; private set; }
        }
    }

    namespace _Edge__Swag_Labs_app._Edge__Swag_Labs_Shopping_Cart
    {
        public class __Checkout : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Checkout(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/45Wc-16UkEGL9AGzhgckVw",
                    DisplayName = "Checkout",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app
    {
        public class __Edge__Swag_Labs_Shopping_Cart : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Edge__Swag_Labs_Shopping_Cart()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/C_u64GstK0iyiJzhBBCDdw",
                    DisplayName = "Edge: Swag Labs Shopping Cart",
                    Screen = this
                };
                Checkout = new _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Shopping_Cart.__Checkout(this, null);
            }

            public _Implementation._Edge__Swag_Labs_app._Edge__Swag_Labs_Shopping_Cart.__Checkout Checkout { get; private set; }
        }
    }

    namespace _Edge__Swag_Labs_app._Sause_Labs___Payment
    {
        public class __Finish : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Finish(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/CfKmniUy5EKaElaE5cHaAQ",
                    DisplayName = "Finish",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app._Sause_Labs___Payment
    {
        public class __Total : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;

            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Total(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/D_W-3yw2mUytHtgeDuRa3w",
                    DisplayName = "Total",
                    Element = this,
                    ParentElement = _parentElementDescriptor,
                    Screen = screenDescriptor
                };
            }
        }
    }

    namespace _Edge__Swag_Labs_app
    {
        public class __Sause_Labs___Payment : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;

            public __Sause_Labs___Payment()
            {
                _screenDescriptor = new ScreenDescriptorDefinition
                {
                    Reference = "d1mKlxCDdkScUHoAOnUyQA/hgVczTb8h0iOSTPHkpP3Yw",
                    DisplayName = "Sause Labs - Payment",
                    Screen = this
                };
                Finish = new _Implementation._Edge__Swag_Labs_app._Sause_Labs___Payment.__Finish(this, null);
                Total = new _Implementation._Edge__Swag_Labs_app._Sause_Labs___Payment.__Total(this, null);
            }

            public _Implementation._Edge__Swag_Labs_app._Sause_Labs___Payment.__Finish Finish { get; private set; }
            public _Implementation._Edge__Swag_Labs_app._Sause_Labs___Payment.__Total Total { get; private set; }
        }
    }
}